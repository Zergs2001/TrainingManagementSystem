﻿namespace MatRoleClaim.Models.ViewModels
{
    public class ClaimViewModel
    {
        public string ClaimId { get; set; }
        public string ClaimType { get; set; }
        public string ClaimValue { get; set; }
        public string Description { get; set; }
        public bool Status { get; set; }
    }
}