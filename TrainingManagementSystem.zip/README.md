# TrainingManagementSystem
# Project run instructions
- Clone Project
- Edit connectionStrings in file Web.config
- Open Package Manager Console
- Run update-database
- Run Project
# Account Admin
- User: admin@gmail.com
- Password: 123456
